# -*- coding: utf-8 -*-
"""
Created on Thu Jun 30 10:06:32 2016

@author: arman
"""

from gensim.summarization import keywords



text="""
  How can I renew my membership online?
  To renew your membership online, please follow these steps:
  Sign in or create a new account by clicking here,
  Click on My account to get access to your online membership account,
  Click on the Renew button,
  Agree to the Member Privileges and Conditions,
  Click on Proceed To Checkout,
  For additional membership renewal options, click here.
  When renewing your membership, please note that all cards on the 
  membership (primary and Spouse cards) will be renewed.
  You will receive a confirmation email when renewal is complete.
  """
  
print(keywords(text,pos_filter=['NN','VV','JJ'],ratio=0.3,lemmatize=True,scores=True))


