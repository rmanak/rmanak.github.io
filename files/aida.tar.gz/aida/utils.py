# -*- coding: utf-8 -*-
"""
Created on Sun Jun 19 12:55:24 2016

@author: arman
"""

from PyDictionary import PyDictionary
#import pickle
import json


def file_to_list(fname,num_cols=1):
    list_ = list()
    with open(fname,'r') as f:
        for line in f:
            if num_cols > 1:
                x = line.rstrip('\n').split()[:num_cols]
            else:
                x = line.rstrip('\n').split()[0]
            list_.append(x)
    return list_
            

import socket
REMOTE_SERVER = "www.google.com"
def is_connected():
  try:
    # see if we can resolve the host name -- tells us if there is
    # a DNS listening
    host = socket.gethostbyname(REMOTE_SERVER)
    # connect to the host -- tells us if the host is actually
    # reachable
    s = socket.create_connection((host, 80), 2)
    return True
  except:
     pass
  return False
  

if __name__ == '__main__':
    dictionary = PyDictionary()
    words = file_to_list('wordlist.txt')
    #treasury = dict()
    
    with open('dictionary.json','r') as fp:
        treasury = json.load(fp)
    
    for (i, word) in enumerate(words):
        
        if word in treasury.keys():
            print("passing:", word)
            continue
        else:
            
            if is_connected():
                treasury[word] = dict()
            else:
                print("Internet connection lost!")
                print("Quitting...")
                break
            
            #meaning_ = dictionary.meaning(word)
            #if meaning_ is None:
            #    treasury[word]['meaning']  = {'NotFound':['NotFound']}
            #else:
            #    treasury[word]['meaning'] = meaning_
                
            syn_ = dictionary.synonym(word)
            if syn_ is None:
                treasury[word]['synonym'] = ['NotFound']
            else:
                treasury[word]['synonym'] = syn_
                
            ant_ = dictionary.antonym(word)
            if ant_ is None:
                treasury[word]['antonym'] = ['NotFound']
            else:
                treasury[word]['antonym'] = ant_
            
            print('{}/{} {}'.format(i,len(words),word),syn_)    
    
    with open('dictionary.json', 'w') as fp:
        json.dump(treasury, fp, sort_keys=False, indent=4)
    
    