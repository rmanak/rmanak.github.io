# -*- coding: utf-8 -*-
"""
Created on Wed Jul  6 21:44:00 2016

@author: arman
"""

x = [1,2,3,4,5,6]

y1 = [0.68,0.79,0.84,0.87,0.89,0.91]

deltay1 = [0.05,0.04,0.03,0.02,0.015,0.0]

x95 = [0,6]
y95= [0.95,0.95]

import matplotlib.pyplot as plt
import numpy as np


# evenly sampled time at 200ms intervals
t = np.arange(0., 5., 0.2)

# red dashes, blue squares and green triangles
plt.errorbar(x,y1,yerr=deltay1,fmt='bo-')
plt.axis([0.5, 6.5, 0.6, 1.0])
plt.title("Top 3 Accuracy as number of rephrasing in train set")
plt.ylabel('Top3 Acc')
plt.xlabel('# Rephrasing')
plt.grid(True)
plt.savefig('acc.png',dpi=300)

