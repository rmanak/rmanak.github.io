from __future__ import print_function
from summa import keywords, summarizer
text="""
  To renew your membership online, please follow these steps
  Sign in or create a new account by clicking here
  Click on My account to get access to your online membership account
  Click on the Renew button
  Agree to the Member Privileges and Conditions
  Click on Proceed To Checkout
  For additional membership renewal options, click here.
  When renewing your membership, please note that all cards on the 
  membership (primary and Spouse cards) will be renewed 
  You will receive a confirmation email when renewal is complete
  For more information, please contact Costco Member Service at 1-800-463-3783, 
  Monday to Friday, between 9 a.m. and 6 p.m. EST.
"""

print(keywords.keywords(text))
print(summarizer.summarize(text))
 
