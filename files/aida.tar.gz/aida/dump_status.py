# -*- coding: utf-8 -*-
"""
Created on Tue Jun 21 13:11:05 2016

@author: arman
"""

import requests
import json
import socket

REMOTE_SERVER = "www.google.com"

def is_connected():
  try:
    # see if we can resolve the host name -- tells us if there is
    # a DNS listening
    host = socket.gethostbyname(REMOTE_SERVER)
    # connect to the host -- tells us if the host is actually
    # reachable
    s = socket.create_connection((host, 80), 2)
    return True
  except:
     pass
  return False
  
access_token = 'a44756803dc47aa45364b890de32a60694f478f4e22a809c6b9c5b74d469f69b'
url_format = 'https://api.groovehq.com/v1/tickets/{}/state?access_token={}'



if __name__ == '__main__':
    
    with open('invoicesimple_state.json','r') as fp:
        database = json.load(fp)
    
    for id_ in range(60000):
        
        if str(id_) in database.keys():
            print("passing, ",id_)
            continue
        
        else:
            if is_connected():
                r = requests.get(url_format.format(id_,access_token))
                database[id_] = dict()
                database[id_]['status'] = r.status_code
                database[id_]['encoding'] = r.encoding
                database[id_]['header'] = dict(r.headers)
                if r.status_code == 200:
                    database[id_]['content'] = r.json()
                else:
                    database[id_]['content'] = {}
                print("id:",id_,"status:",r.status_code)
            else:
                
                print("Internet connection lost!")
                print("Quitting...")
                break
    
    with open('invoicesimple_state.json', 'w') as fp:
        json.dump(database, fp, sort_keys=False, indent=4)