# -*- coding: utf-8 -*-
"""
Created on Tue Jun 14 14:23:48 2016

@author: arman
"""

################# UPPER CASE ACRONYM #######################
# if converted to lower case might have a different meaning
# apply this before transforming to lower case
############################################################

acronym_with_dot_normalizer_table = {' u.s.a ': 'unitedstates',\
                                     ' u.s. ': 'unitedstates',}

upper_case_acronym_normalizer_table = {' US ':' unitedstates ',\
                                       ' AM ':' antemeridiem ',\
                                       ' Sat ':' saturday ',\
                                       ' USA ':' unitedstates ',\
                                       ' CAN ':' canada ',\
                                       ' FAQ ': ' frequent ask question ',\
                                       ' PC ': ' personal computer ',\
                                       ' ID ': 'identification document',\
                                       }
                         

english_contraction_normalizer_table = {"i'm'":"i am",\
                                        "i've":"i have",\
                                        "i'd":'i would had',\
                                        "can't":"cannot",\
                                        "you're":"you are",\
                                        "don't":"do not",\
                                        "didn't":"did not",\
                                        "hasn't":"has not",\
                                        "haven't":"have not",\
                                        "do not":"do not",\
                                        "did not":"did not",\
                                        "can not":"can not",\
                                        "has not":"has not",\
                                        "have not":"have not",\
                                        "isn't":"is not",}
                                        
                                        
                                        
lower_case_acronym_normalizer_table = {' p.o. ':' post office ',\
                                       ' p. o. ':' post office ',\
                                       ' po ':' post office ',\
                                       ' p o ':' post office ',}
                                       
                                       
                               
numbers_normalizer_table = {'1':' one ',\
                            '2':' two ',\
                            '3':' three ',\
                            '4':' four ',\
                            '5':' five ',\
                            '6':' six ',\
                            '7':' seven ',\
                            '8':' eight ',\
                            '9':' nine ',\
                            '0':' zero ',\
                            '$':' dollar ',\
                            '%':' percentage ',\
                            '&':' and ',\
                            '#':' number '}

other_normalizer_table = {'log in':' login ',\
                          'log-in':' login ',\
                          'log on':' login ',\
                          'log into':' login to ',\
                          'sign in': 'login',\
                          'signin': 'login',\
                          'loggin':'login',\
                          'e-mail':'email',\
                          ' e mail':' email',\
                          ' pre ':' pre',\
                          ' info ': ' information ',\
                          'visa card':'visacard',\
                          'visa':'visacard',\
                          'master card':'mastercard',\
                          'credit card':'creditcard',\
                          'sign up': 'register',\
                          'signup': 'register',\
                          'package': 'order',\
			  'canada': 'worldwide',\
			  'unitedstates': 'worldwide',\
			  'china': 'worldwide',\
			  'send back': 'return',\
			  'send it back': 'return',\
                          'overseas': 'worldwide',\
                          'everywhere': 'any address',\
			  'anywhere': 'any address',\
			  'global': 'worldwide',\
			  'delivery service': 'shipping methods',\
			  'shipment method': 'shipping methods',\
			  'log on': 'login',\
		          'what are the steps': 'how',\
			  'what is the process': 'how',\
			  'get in touch': 'contact',\
                          'edit': 'change',\
                          'details': 'information',\
                          'quick': 'fast',\
			  'rush': 'fast',\
                          'right away': 'fast',\
                          'logging in':'login',\
                          'find out':'know',\
                          'no-cost':'free',\
                          'no cost': 'free',\
                          'safe':'secure',\
                          'pick up': 'pickup',\
                          'how young': 'how old',\
                          'out of stock': 'soldout',\
                          'sold out':'soldout',\
                          'make sure': 'ensure',\
                          'auto-payment': 'auto payment',\
                          'how much': 'howmuch',\
                          # **** danger zone *****
                          'site': 'website',\
                          'checking out': 'checkout',\
                          'check out': 'checkout',\
                          'join': 'register',\
                          # **** end of danger zone ****
                          }

punctuations_normalizer_table = {',':' ',\
                                 '!':' ',\
                                 '?':' ',\
                                 }

business_related_normalizer_table = { 'item':'order',\
                                      'shipment':'order',\
                                      }
