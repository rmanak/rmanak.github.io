# -*- coding: utf-8 -*-
"""
Created on Thu Jun 23 13:06:25 2016

@author: arman
"""

import requests
import json
import socket
import numpy as np
import seaborn as sns

if __name__ == '__main__':
    
    with open('invoicesimple.json','r') as fp:
        database = json.load(fp)
    
    clean_database = {}
    
    for (k,v) in database.items():
        if v['status'] == 200:
            clean_database[k] =  [ msg['body'] for msg in v['content']['messages'] ]
            print(k,"completed.")
            
        
    N_ = len(clean_database.keys())
    
    len_list = list()
    
    for (k,v) in clean_database.items():
        len_list.append(len(v))
        
    len_list = np.array(len_list)
    
    sns.distplot(len_list,kde=False)
    
    
    html_text = list()
    max_count = 5000
    style_text="""
    <style>
.response1 {background:green!important; border: 10px solid grey; margin-left:10px; padding:20px; margin-top:10px;}
.response2 {background:yellow!important; border: 20px solid grey; margin-left:50px; padding:50px; margin-top:10px;}
.response3 {background:red!important; border: 30px solid grey; margin-left:90px; padding:100px; margin-top:10px}
.response1-2 {background:blue!important;}
.response2-2 {background:blue!important;}
.response1-3 {background:blue!important;}
.response2-3 {background:blue!important;}
.response3-3 {background:blue!important;}
</style>
"""
    html_text.append(style_text)
    for (k,v) in clean_database.items():
        if len(v) == 1:
            html_text.append('<div class="response1">\n  <p>====1=====</p> \n')
            html_text.append(v[0])
            html_text.append('\n</div>\n')
            
        if len(v) == 2:
            html_text.append('<div class="response2">\n <p>====2====</p>\n')
            html_text.append('<div style="clear:both">&nbsp;</div>')
            html_text.append('<div class="response1-2">\n <p> ---1/2----- </p>\n')
            html_text.append(v[0])
            html_text.append('\n</div>\n')
            html_text.append('<div style="clear:both">&nbsp;</div>')
            html_text.append('<div class="response2-2">\n <p>----2/2-----</p> \n')
            html_text.append(v[1])
            html_text.append('\n</div>\n')
            html_text.append('\n</div>\n')
            
        if len(v) == 3:
            html_text.append('<div class="response3">\n =====3=====')
            html_text.append('<div style="clear:both">&nbsp;</div>')
            html_text.append('<div class="response1-3">\n <p>----1/3----</p>\n')
            html_text.append(v[0])
            html_text.append('\n</div>\n')
            html_text.append('<div style="clear:both">&nbsp;</div>')
            html_text.append('<div class="response2-3">\n <p>----2/3----</p>\n')
            html_text.append(v[1])
            html_text.append('\n</div>\n')
            html_text.append('<div style="clear:both">&nbsp;</div>')
            html_text.append('<div class="response3-3">\n <p>----3/3---</p>\n')
            html_text.append(v[2])
            html_text.append('\n</div>\n')
            html_text.append('<div style="clear:both">&nbsp;</div>')
            html_text.append('\n</div>\n')
            
        if len(v) == 4:
            html_text.append('<div class="response3">\n =====4=====')
            html_text.append('<div style="clear:both">&nbsp;</div>')
            html_text.append('<div class="response1-3">\n <p>----1/4----</p>\n')
            html_text.append(v[0])
            html_text.append('\n</div>\n')
            html_text.append('<div style="clear:both">&nbsp;</div>')
            html_text.append('<div class="response1-3">\n <p>----2/4----</p>\n')
            html_text.append(v[1])
            html_text.append('\n</div>\n')
            html_text.append('<div style="clear:both">&nbsp;</div>')
            html_text.append('<div class="response1-3">\n <p>----3/4----</p>\n')
            html_text.append(v[2])
            html_text.append('\n</div>\n')
            html_text.append('<div style="clear:both">&nbsp;</div>')
            html_text.append('<div class="response1-3">\n <p>----4/4---</p>\n')
            html_text.append(v[3])
            html_text.append('\n</div>\n')
            html_text.append('<div style="clear:both">&nbsp;</div>')
            html_text.append('\n</div>\n')
            
        
        if len(html_text) > max_count:
            break
    
    with open('html_text.html','wt') as htmlfh:
        
        for txt in html_text:
           htmlfh.write(txt)
          
            
            
            
            
            
    
    
    
    
    
    