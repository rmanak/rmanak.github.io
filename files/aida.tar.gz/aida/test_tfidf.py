# -*- coding: utf-8 -*-
"""
Created on Thu Jun 30 12:58:30 2016

@author: arman
"""

import pandas as pd
import numpy as np
import re
from nlp_utils import stemmer, tokenizer, stopwords, safe_divide, Color
from sklearn.feature_extraction.text import TfidfVectorizer
import normalizer as nz


aida_stopwords = stopwords.difference(set(['where','how','when','what','who']))

def normalize(s):
    
    for (k,v) in nz.punctuations_normalizer_table.items():
        s = s.replace(k,v)
    
    for (k,v) in nz.upper_case_acronym_normalizer_table.items():
        s = s.replace(k,v)
    
    s = s.lower()
    
    for (k,v) in nz.english_contraction_normalizer_table.items():
        s = s.replace(k,v)
    
    for (k,v) in nz.lower_case_acronym_normalizer_table.items():
        s = s.replace(k,v)
    
    for (k,v) in nz.numbers_normalizer_table.items():
        s = s.replace(k,v)
    
    for (k,v) in nz.other_normalizer_table.items():
        s = s.replace(k,v)
        
    for (k,v) in nz.business_related_normalizer_table.items():
        s = s.replace(k,v)
     
    s = re.sub(r'(?u)([a-z])-([a-z])',r'\1\2',s)
    
    return s
    
def stem(s):
    global aida_stopwords
    s = tokenizer.tokenize(s)
    s = [stemmer.stem(w) for w in s if w not in aida_stopwords]
    return ' '.join(s)
    
    

def get_database():
    DT = pd.read_csv('/Users/arman/aida/questions.csv')
    DT_org = DT.copy()
    for i in range(6):
        col_name = 'F' + str(i+1)
        DT[col_name] = DT[col_name].map(normalize)
        DT[col_name] = DT[col_name].map(stem)
    return DT, DT_org
    
def get_cv_database():
    DT = pd.read_csv('/Users/arman/aida/MT_questions.csv')
    DT['QID'] = DT['Input.QID']
    DT['ReWrites'] = DT['Answer.WritingTexts'].map(lambda x: x.split('|'))
    return DT.loc[DT['Approve']==1, ['QID','Input.Question','ReWrites']].reset_index()
    
def jaccard_distance(s1,s2):
    s1 = set(s1.split())
    s2 = set(s2.split())
    int_set = s1.intersection(s2)
    uni_set = s1.union(s2)
    return safe_divide(len(int_set),len(uni_set))
    
def jaccard_distance2(s1,s2):
    s1 = set(s1.split())
    s2 = set(s2.split())
    int_set = s1.intersection(s2)
    uni_set = s1.union(s2)
    return safe_divide(len(int_set),len(s1))
    
def jaccard_coverage(s1,s2):
    s1 = set(s1.split())
    s2 = set(s2.split())
    int_set = s1.intersection(s2)
    uni_set = s1.union(s2)
    return safe_divide(len(int_set),1.0)

def str_column_merger_df(df,*args):
    
    sep_ = ' '
    if len(args) == 0:
        return None
        
    elif len(args) == 1:
        return df[args[0]]
        
    else:
        accumulate_col = df[args[0]]
        for i in args[1:]:
            accumulate_col = accumulate_col + sep_ + df[i]
        return accumulate_col
    
if __name__ == '__main__':
    
    DT, DT_org = get_database()
    
    DTCV = get_cv_database()
    
    DT['all_terms'] = str_column_merger_df(DT,'F1','F2','F3','F4','F5','F6')
    
    #DT['all_terms'] = str_column_merger_df(DT,'F2','F3','F4','F5','F6')
    
    #DT['all_terms'] = str_column_merger_df(DT,'F1','F3','F4','F5','F6')
    
    #DT['all_terms'] = str_column_merger_df(DT,'F2','F1','F4','F5','F6')
    
    #DT['all_terms'] = str_column_merger_df(DT,'F2','F3','F1','F5','F6')
    
    #DT['all_terms'] = str_column_merger_df(DT,'F2','F3','F4','F1','F6')
    
    #DT['all_terms'] = str_column_merger_df(DT,'F2','F3','F4','F5','F1')
    
    #DT['all_terms'] = str_column_merger_df(DT,'F3','F4','F5','F6')
    
    #DT['all_terms'] = str_column_merger_df(DT,'F1','F2','F5','F6')
    
    #DT['all_terms'] = str_column_merger_df(DT,'F3','F4','F1','F2')
    
    #DT['all_terms'] = str_column_merger_df(DT,'F3','F5','F1','F2')
    
    #DT['all_terms'] = str_column_merger_df(DT,'F1','F2','F3')
    
    #DT['all_terms'] = str_column_merger_df(DT,'F2','F3','F4')
    
    #DT['all_terms'] = str_column_merger_df(DT,'F3','F4','F5')
    
    #DT['all_terms'] = str_column_merger_df(DT,'F4','F5','F6')
    
    #DT['all_terms'] = str_column_merger_df(DT,'F1','F5','F6')
    
    #DT['all_terms'] = str_column_merger_df(DT,'F2','F5','F6')
    
    #DT['all_terms'] = str_column_merger_df(DT,'F1','F2')
    
    #DT['all_terms'] = str_column_merger_df(DT,'F2','F4')
    
    #DT['all_terms'] = str_column_merger_df(DT,'F1')



                      
    corpus = np.array(DT['all_terms'])
    
    vectorizer = TfidfVectorizer(max_df=0.8,  max_features=None, ngram_range=(1, 2),\
                      use_idf=True, smooth_idf=True,sublinear_tf=True,\
                      stop_words = None)
    
    vectorizer.fit(corpus)
    
    corpus_transformed = vectorizer.transform(corpus).toarray()
    
    question_id = np.array(DT['QID'])
    question = np.array(DT_org['F1'])
    question_identifier = DT['Qidentifier']
    _keywords = DT['Keywords1'].map(normalize)
    _keywords = _keywords.map(stem)
    
    
    all_scores = list()
    mistake_count = 0
    for i in range(len(DTCV)):
      ss = DTCV.loc[i,'ReWrites']
      org_q = DTCV.loc[i,'Input.Question']
      qid_test = DTCV.loc[i,'QID']
      all_sub_scores = list()
      for s in ss:
        org_s = s
        s = stem(normalize(s))
        
        jacc_result = [jaccard_coverage(x,s) for x in _keywords]  
        
        jacc_result = np.array(jacc_result)
        
        input_transformed = vectorizer.transform([s]).toarray()
        
        query_result = corpus_transformed.dot(input_transformed.T)
        
        query_result = [query_result[i][0] for i in range(len(query_result))]
        
        query_result = 1.0*np.array(query_result) + 0.0*jacc_result
        
        sorting_index = np.argsort(-query_result)
        
        top_3_qid = question_id[sorting_index][:3]
        
        if qid_test == top_3_qid[0]:
            score_ = 1.0
        elif qid_test == top_3_qid[1]:
            score_ = 0.5
        elif qid_test == top_3_qid[2]:
            score_ = 0.333
        else:
            mistake_count += 1
            score_ = 0.0
            top_3_questions = question[sorting_index][:3]
            #print(mistake_count)
            #print("original Q:",org_q,"\nrephrased Q:",org_s,"\nTop 3:",top_3_questions)
            #print("===============================================")
            
        all_sub_scores.append(score_)
        
      all_scores.append(all_sub_scores)
        
    sum_score = 0.0
    count = 0
    for score_list in all_scores:
        for ii in score_list:
            sum_score += ii
            count += 1
    
    print('avg score = ',sum_score/count)
    
    
    
        
        
    
    
    
