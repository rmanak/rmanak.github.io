# -*- coding: utf-8 -*-
"""
Created on Sun Jun 12 14:40:14 2016

@author: arman
"""

import pandas as pd
import numpy as np
import re
from nlp_utils import stemmer, tokenizer, stopwords, safe_divide, Color
from sklearn.feature_extraction.text import TfidfVectorizer
import normalizer as nz


aida_stopwords = stopwords.difference(set(['where','how','when','what','who','why',\
                                           'which','further','between','after',\
                                           'before','below','again','during']))

def normalize(s):
    
    for (k,v) in nz.punctuations_normalizer_table.items():
        s = s.replace(k,v)
    
    for (k,v) in nz.upper_case_acronym_normalizer_table.items():
        s = s.replace(k,v)
    
    s = s.lower()
    
    for (k,v) in nz.english_contraction_normalizer_table.items():
        s = s.replace(k,v)
    
    for (k,v) in nz.lower_case_acronym_normalizer_table.items():
        s = s.replace(k,v)
    
    for (k,v) in nz.numbers_normalizer_table.items():
        s = s.replace(k,v)
    
    for (k,v) in nz.other_normalizer_table.items():
        s = s.replace(k,v)
        
    for (k,v) in nz.business_related_normalizer_table.items():
        s = s.replace(k,v)
     
    s = re.sub(r'(?u)([a-z])-([a-z])',r'\1\2',s)
    
    return s
    
def stem(s):
    global aida_stopwords
    s = tokenizer.tokenize(s)
    s = [stemmer.stem(w) for w in s if w not in aida_stopwords]
    return ' '.join(s)
    
    

def get_database():
    DT = pd.read_csv('/Users/arman/aida/questions.csv')
    DT_org = DT.copy()
    for i in range(6):
        col_name = 'F' + str(i+1)
        DT[col_name] = DT[col_name].map(normalize)
        DT[col_name] = DT[col_name].map(stem)
    return DT, DT_org
    
def jaccard_distance(s1,s2):
    s1 = set(s1.split())
    s2 = set(s2.split())
    int_set = s1.intersection(s2)
    uni_set = s1.union(s2)
    return safe_divide(len(int_set),len(uni_set))

def str_column_merger_df(df,*args):
    
    sep_ = ' '
    if len(args) == 0:
        return None
        
    elif len(args) == 1:
        return df[args[0]]
        
    else:
        accumulate_col = df[args[0]]
        for i in args[1:]:
            accumulate_col = accumulate_col + sep_ + df[i]
        return accumulate_col

def softmax(w, t = 0.1):
    e = np.exp(np.array(w) / t)
    dist = e / np.sum(e)
    return dist
    
if __name__ == '__main__':
    
    DT, DT_org = get_database()
    
    DT['all_terms'] = str_column_merger_df(DT,'F1','F2','F3','F4','F5','F6')
                      
    corpus = np.array(DT['all_terms'])
    
    vectorizer = TfidfVectorizer(max_df=0.8,  max_features=None, ngram_range=(1, 2),\
                      use_idf=True, smooth_idf=True,sublinear_tf=True,\
                      stop_words = None)
    
    vectorizer.fit(corpus)
    
    corpus_transformed = vectorizer.transform(corpus).toarray()
    
    question_id = DT['QID']
    question = DT_org['F1']
    question_identifier = DT['Qidentifier']
    _keywords = DT['Keywords1'].map(normalize)
    _keywords = _keywords.map(stem)
    
    s = ''
    
    print("Hi! ",end='')
    
    while (s != 'exit'):
        print("I am Aida, ask me a common customer service question:> ",end='')
        
        s = input()
        
        if (s == 'exit'):
            break
        
        s = stem(normalize(s))
        
        jacc_result = [jaccard_distance(x,s) for x in _keywords]  
        
        jacc_result = np.array(jacc_result)
        
        input_transformed = vectorizer.transform([s]).toarray()
        
        query_result = corpus_transformed.dot(input_transformed.T)
        
        query_result = [query_result[i][0] for i in range(len(query_result))]

        query_result = 0.5*np.array(query_result) + 0.5*jacc_result
        
        query_result = softmax(query_result)

        sorting_index = np.argsort(-query_result)
        
        q_bundle = zip(question_id[sorting_index][:3],\
                       question[sorting_index][:3],\
                       question_identifier[sorting_index][:3],\
                       query_result[sorting_index][:3])
        
        top_relevance = query_result[sorting_index][:1]
        
        if (top_relevance < 0.01):
            print("\nI am not sure if I know the answer to that! :-(")
            print("How about a question like, 'what are the payment types you accept?'\n")
            
        else:
            
            for (qnumber, q, qidf,relevance) in q_bundle:
                #print('Question number = ',qnumber)
                print('Question identifier = ', Color.GREEN + str(qidf) + Color.END)
                print('Question = ',  Color.BOLD + q + Color.END)
                print('Relevance =',Color.CYAN + str(relevance) + Color.END)
                print("================================================")
                 
    
    
    
