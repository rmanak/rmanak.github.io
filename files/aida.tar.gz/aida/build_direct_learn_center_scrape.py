# -*- coding: utf-8 -*-
"""
Created on Tue Jun 21 13:53:07 2016

@author: arman
"""

https://www.builddirect.com/learning-center/category/flooring/hardwood-flooring/
https://www.builddirect.com/learning-center/category/flooring/hardwood-flooring/page/3/
9

https://www.builddirect.com/learning-center/category/home-improvement-info/
https://www.builddirect.com/learning-center/category/home-improvement-info/page/3/
7

https://www.builddirect.com/learning-center/category/flooring/ceramic-porcelain-tile/
https://www.builddirect.com/learning-center/category/flooring/ceramic-porcelain-tile/page/2/
5

https://www.builddirect.com/learning-center/category/outdoor/decking/
https://www.builddirect.com/learning-center/category/outdoor/decking/page/4/
4

https://www.builddirect.com/learning-center/category/flooring/bamboo-flooring/
https://www.builddirect.com/learning-center/category/flooring/bamboo-flooring/page/3/
4

https://www.builddirect.com/learning-center/category/flooring/laminate-flooring/
3

https://www.builddirect.com/learning-center/category/flooring/carpet-rugs/
3

https://www.builddirect.com/learning-center/category/building-materials/siding/
3

https://www.builddirect.com/learning-center/category/flooring/travertine-tile/
3

https://www.builddirect.com/learning-center/category/flooring/vinyl-flooring/
2

https://www.builddirect.com/learning-center/category/flooring/engineered-hardwood-flooring/
2

https://www.builddirect.com/learning-center/category/flooring/marble-tile/
2

https://www.builddirect.com/learning-center/category/kitchen-bath/wall-tile-mosaics/
2

https://www.builddirect.com/learning-center/category/flooring/flooring-accessories/
1

https://www.builddirect.com/learning-center/category/flooring/cork-flooring/
1

https://www.builddirect.com/learning-center/category/flooring/rubber-flooring/
1

https://www.builddirect.com/learning-center/category/outdoor/outdoor-accessories/
1

https://www.builddirect.com/learning-center/category/flooring/slate-tile/
1

https://www.builddirect.com/learning-center/category/kitchen-bath/countertops/
1

https://www.builddirect.com/learning-center/category/building-materials/panel-products/
1


